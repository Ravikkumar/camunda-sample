package org.infoorigin.bpm.securerestsample;

import org.camunda.bpm.engine.rest.security.auth.ProcessEngineAuthenticationFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

	
	@Bean
	public FilterRegistrationBean<ProcessEngineAuthenticationFilter> authenticationFilter() {
		
		FilterRegistrationBean<ProcessEngineAuthenticationFilter> filter = new FilterRegistrationBean<ProcessEngineAuthenticationFilter>();
		
		//set filter
		filter.setName("camunda-auth");
		filter.setFilter(new ProcessEngineAuthenticationFilter());
		//set url pattern
		filter.addUrlPatterns("/engine-rest/*");
		
		//set init parameter
		filter.addInitParameter("authentication-provider", "org.camunda.bpm.engine.rest.security.auth.impl.HttpBasicAuthenticationProvider");
		
		filter.setOrder(1);
		return filter;
	}
	
}
