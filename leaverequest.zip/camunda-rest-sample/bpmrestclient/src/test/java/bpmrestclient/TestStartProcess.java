package bpmrestclient;

import org.junit.Before;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class TestStartProcess {

	String path="";
	
	@Before
    public void setup() {
        RestAssured.baseURI = "http://localhost:8080/engine-rest";
        path = "/process-definition/key/leaveRequest/start";
    }
	
    @Test
	public void test() {
		
		
		Response response = RestAssured.given().auth().basic("ravik", "demo12#")
                .contentType(ContentType.JSON)
                .body("{}")
                .post(path)
                .then().extract().response();
		
		System.out.println("response status code : "+response.getStatusCode());
		System.out.println("Response JSON : "+ response.asPrettyString());
		
	}
}
