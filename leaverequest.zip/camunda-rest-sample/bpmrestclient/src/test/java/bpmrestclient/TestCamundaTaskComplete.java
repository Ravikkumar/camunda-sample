package bpmrestclient;

import org.junit.Before;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class TestCamundaTaskComplete {

	String taskListPath="";
	String taskCompletePath="";
	
	@Before
    public void setup() {
        RestAssured.baseURI = "http://localhost:8080/engine-rest";
        taskListPath = "/task";
    }
	
    @Test
	public void test() {
		
		
		Response response = RestAssured.given().auth().basic("ravik", "demo12#")
                .contentType(ContentType.JSON)
                .get(taskListPath)
                .then().extract().response();
		
		System.out.println("response status code : "+response.getStatusCode());
		System.out.println("Response JSON : "+ response.asPrettyString());
		
		JsonPath jsonPathEvaluator = response.jsonPath();
		
		String taskId = jsonPathEvaluator.getString("id").replace("[", "").replace("]", "").trim();
		
		//
		System.out.println("----------------------------------- Completing task..."+taskId);
		
		taskCompletePath = "/task/"+taskId + "/complete";
		
		
		  response = RestAssured.given().auth().basic("ravik", "demo12#")
		  .contentType(ContentType.JSON) .body("{\"variables\":\r\n" +
		  "    {\"numberOfDays\": {\"value\": \"2\"}}\r\n" + "}")
		  .post(taskCompletePath) .then().extract().response();
		  
		  
		  System.out.println("Status : " + response.getStatusCode());
		 
		
	}
	
}
