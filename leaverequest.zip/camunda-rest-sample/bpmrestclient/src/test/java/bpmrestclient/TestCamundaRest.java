package bpmrestclient;


import org.junit.Before;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class TestCamundaRest {
	
	String path="";
	
	@Before
    public void setup() {
        RestAssured.baseURI = "http://localhost:8080/engine-rest";
        path = "/process-definition?latestVersion=true";
    }
	
    @Test
	public void test() {
		
		
		Response response = RestAssured.given().auth().basic("ravik", "demo12#")
                .contentType(ContentType.JSON)
                .get(path)
                .then().extract().response();
		
		System.out.println(response.asPrettyString());
		
	}

}
